# ✨ Devi Chandran's Portfolio

A cute, bubbly, and fun portfolio website built with React!

## 🚀 Deploy on Vercel

1. Push this folder to a GitHub repository
2. Go to [vercel.com](https://vercel.com) and click **"New Project"**
3. Import your GitHub repo
4. Vercel will auto-detect it as a React app
5. Click **Deploy** — you're live! 🎉

## 🛠️ Run Locally

```bash
npm install
npm start
```

## 🏗️ Build for Production

```bash
npm run build
```

## ✨ Features
- 🎀 Cute pink & pastel aesthetic
- 🫧 Floating animated bubbles background
- 🖱️ Custom cursor with ring effect
- 💖 Sparkle effects on every click
- 🔊 Pop sounds on navigation
- 📱 Fully responsive
- 🌊 Smooth scroll & reveal animations
- 💌 Contact form with mailto fallback
- 🔗 LinkedIn, YouTube & Email connect links

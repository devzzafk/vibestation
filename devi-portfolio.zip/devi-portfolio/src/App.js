import React, { useState, useEffect, useRef, useCallback } from 'react';

// ─── Pop Sound Generator ───────────────────────────────────────────
function playPop() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.08);
    gainNode.gain.setValueAtTime(0.25, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + 0.15);
  } catch (e) {}
}

// ─── Sparkle Effect ─────────────────────────────────────────────────
function createSparkle(x, y) {
  const sparkles = ['✨', '💖', '⭐', '🌸', '💫', '🌟', '💕', '🎀'];
  const el = document.createElement('div');
  el.className = 'sparkle-pop';
  el.textContent = sparkles[Math.floor(Math.random() * sparkles.length)];
  el.style.left = x + 'px';
  el.style.top = y + 'px';
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 700);
}

// ─── Custom Cursor ──────────────────────────────────────────────────
function Cursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  const mouse = useRef({ x: 0, y: 0 });
  const ring = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e) => {
      mouse.current = { x: e.clientX, y: e.clientY };
      if (dotRef.current) {
        dotRef.current.style.left = e.clientX + 'px';
        dotRef.current.style.top = e.clientY + 'px';
      }
    };

    let raf;
    const followRing = () => {
      ring.current.x += (mouse.current.x - ring.current.x) * 0.12;
      ring.current.y += (mouse.current.y - ring.current.y) * 0.12;
      if (ringRef.current) {
        ringRef.current.style.left = ring.current.x + 'px';
        ringRef.current.style.top = ring.current.y + 'px';
      }
      raf = requestAnimationFrame(followRing);
    };
    raf = requestAnimationFrame(followRing);

    const onEnter = () => ringRef.current?.classList.add('hovered');
    const onLeave = () => ringRef.current?.classList.remove('hovered');

    document.addEventListener('mousemove', onMove);
    document.querySelectorAll('button, a, [role="button"]').forEach(el => {
      el.addEventListener('mouseenter', onEnter);
      el.addEventListener('mouseleave', onLeave);
    });

    return () => {
      document.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <>
      <div className="cursor-dot" ref={dotRef} />
      <div className="cursor-ring" ref={ringRef} />
    </>
  );
}

// ─── Floating Bubbles Background ────────────────────────────────────
function BubblesBg() {
  const colors = [
    '#ffb3c6', '#c9b8ff', '#b8f0e0', '#fff3b0', '#b8e0ff', '#ffcba4'
  ];
  const bubbles = Array.from({ length: 18 }, (_, i) => ({
    id: i,
    size: Math.random() * 80 + 30,
    left: Math.random() * 100,
    color: colors[Math.floor(Math.random() * colors.length)],
    duration: Math.random() * 18 + 14,
    delay: Math.random() * 20,
  }));

  return (
    <div className="bubbles-bg">
      {bubbles.map(b => (
        <div
          key={b.id}
          className="bubble"
          style={{
            width: b.size,
            height: b.size,
            left: `${b.left}%`,
            background: b.color,
            animationDuration: `${b.duration}s`,
            animationDelay: `${b.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Navbar ──────────────────────────────────────────────────────────
function Navbar({ active, scrollTo }) {
  const items = ['Home', 'About', 'Projects', 'Tutorials', 'Contact'];

  const handleClick = (item) => {
    playPop();
    scrollTo(item.toLowerCase());
  };

  return (
    <nav className="navbar">
      <span className="nav-logo">devi ✨</span>
      {items.map(item => (
        <button
          key={item}
          className={`nav-item ${active === item.toLowerCase() ? 'active' : ''}`}
          onClick={() => handleClick(item)}
        >
          {item}
        </button>
      ))}
    </nav>
  );
}

// ─── Hero Section ────────────────────────────────────────────────────
function Hero({ scrollTo }) {
  const tags = ['🧠 BCI Researcher', '⚡ AI Developer', '🎨 UI/UX', '🐍 Python', '🌐 Full Stack', '📡 Neurotechnology'];

  return (
    <section id="home" className="hero">
      {/* decorative blobs */}
      <div className="hero-blob" style={{ width: 400, height: 400, background: 'rgba(255,179,198,0.25)', top: '10%', left: '-8%' }} />
      <div className="hero-blob" style={{ width: 300, height: 300, background: 'rgba(201,184,255,0.2)', top: '20%', right: '-5%' }} />
      <div className="hero-blob" style={{ width: 250, height: 250, background: 'rgba(184,224,255,0.2)', bottom: '15%', left: '20%' }} />

      <div className="hero-avatar-wrap">
        <div className="hero-avatar">🧬</div>
        <div className="hero-badge">✨</div>
      </div>

      <p className="hero-greeting">hey there, i'm</p>
      <h1 className="hero-name">Devi Chandran</h1>
      <p className="hero-tagline">
        B.Tech CSE student · BCI & Neurotechnology enthusiast ·<br />
        AI-powered developer · Building the future, one synapse at a time 🌸
      </p>

      <div className="hero-tags">
        {tags.map(tag => (
          <span key={tag} className="hero-tag">{tag}</span>
        ))}
      </div>

      <div className="hero-cta-group">
        <button className="btn-primary" onClick={() => { playPop(); scrollTo('projects'); }}>
          🚀 See My Projects
        </button>
        <button className="btn-secondary" onClick={() => { playPop(); scrollTo('contact'); }}>
          💌 Get In Touch
        </button>
      </div>
    </section>
  );
}

// ─── About Section ───────────────────────────────────────────────────
function About() {
  const skillGroups = [
    {
      title: '🧠 AI & Agentic Systems',
      color: 'lavender',
      skills: ['Machine Learning', 'Deep Learning', 'Generative AI', 'RAG', 'LangChain', 'HuggingFace'],
    },
    {
      title: '⚡ Frameworks & Libraries',
      color: 'pink',
      skills: ['React', 'Node.js', 'Next.js', 'Flutter', 'TensorFlow', 'FastAPI', 'Streamlit', 'Gradio', 'OpenCV', 'YOLO'],
    },
    {
      title: '☁️ Platforms',
      color: 'sky',
      skills: ['Vercel', 'Render', 'Firebase', 'Supabase', 'GitHub', 'VS Code'],
    },
    {
      title: '🗄️ Databases',
      color: 'mint',
      skills: ['Supabase', 'Firebase', 'MySQL', 'MongoDB'],
    },
  ];

  return (
    <section id="about">
      <div className="section-wrap">
        <h2 className="section-title">About <span>Me</span> 💖</h2>
        <p className="section-subtitle">a little peek into who i am ✨</p>

        <div className="about-grid reveal">
          <div>
            <div className="about-card" style={{ marginBottom: 24 }}>
              <h3>🎓 Education</h3>
              <div className="role-badge">📚 B.Tech CSE Undergraduate</div>
              <p>
                Currently studying Computer Science Engineering at <strong>LBS Institute of Technology for Women, Thiruvananthapuram</strong> — building a strong foundation in software development, algorithms, and system design.
              </p>
            </div>

            <div className="about-card" style={{ marginBottom: 24 }}>
              <h3>🔬 What I Love</h3>
              <p>
                I'm obsessed with the intersection of <strong>neurotechnology and AI</strong>. I work on Brain-Computer Interface projects, explore how machines can understand neural signals, and build AI-powered tools that are both functional and beautiful. 🧠💕
              </p>
            </div>

            <div className="about-card">
              <h3>🌱 Key Skills</h3>
              <div className="skills-chips">
                {['Python', 'HTML/CSS', 'Neurotechnology', 'BCI', 'AI Development', 'UI/UX Coding'].map(s => (
                  <span key={s} className="chip chip-pink">{s}</span>
                ))}
              </div>
            </div>
          </div>

          <div>
            {skillGroups.map(group => (
              <div className="about-card" key={group.title} style={{ marginBottom: 20 }}>
                <h3>{group.title}</h3>
                <div className="skills-chips">
                  {group.skills.map(s => (
                    <span key={s} className={`chip chip-${group.color}`}>{s}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="tinkerhub-banner reveal">
          <span className="tk-icon">🔧</span>
          <div>
            <h3>TinkerHub First Year Coordinator 2025 🏆</h3>
            <p>
              Proud coordinator at my campus community chapter! Co-organized a web development session and led an online session on RAG (Retrieval-Augmented Generation) as part of TinkerHub's campus initiative. Building, learning, and sharing — that's the vibe! ✨
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Projects Section ────────────────────────────────────────────────
function Projects() {
  const projects = [
    {
      emoji: '🧠',
      title: 'BCI Signal → Intent Classification',
      desc: 'A machine learning pipeline that processes neural-signal-like time-series data and classifies user intent using simulated or open datasets. Fully software-focused and hardware-agnostic.',
      stack: ['Python', 'NumPy', 'Pandas', 'Scikit-learn'],
    },
    {
      emoji: '📊',
      title: 'Neural Signal Visualization Dashboard',
      desc: 'An interactive visualization tool to compare raw and filtered neural signals, helping understand noise, patterns, and signal quality in brain data.',
      stack: ['Python', 'Matplotlib', 'Plotly'],
    },
    {
      emoji: '🔬',
      title: 'Neuralink Software Stack Analysis',
      desc: 'A deep technical analysis of Neuralink from a software engineering perspective — covering data pipelines, real-time constraints, scalability, and safety considerations.',
      stack: ['Research', 'Technical Write-up'],
    },
  ];

  return (
    <section id="projects">
      <div className="section-wrap">
        <h2 className="section-title">Featured <span>Projects</span> 🚀</h2>
        <p className="section-subtitle">things i've built with love & curiosity 🔭</p>

        <div className="projects-grid reveal">
          {projects.map(p => (
            <div className="project-card" key={p.title}>
              <span className="project-emoji">{p.emoji}</span>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
              <div className="project-stack">
                {p.stack.map(s => (
                  <span key={s} className="stack-tag">{s}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Tutorials Section ───────────────────────────────────────────────
function Tutorials() {
  const cards = [
    {
      icon: '🤖',
      title: 'AI-Powered Development',
      desc: 'Tutorials on building intelligent applications, from concept to deployment. Making AI accessible and fun!',
    },
    {
      icon: '📚',
      title: 'RAG Sessions',
      desc: 'Online sessions on Retrieval-Augmented Generation — one of the hottest techniques in modern AI apps.',
    },
    {
      icon: '🌐',
      title: 'Web Development',
      desc: 'Co-hosted web dev sessions as part of TinkerHub campus community\'s initiatives. Let\'s build together!',
    },
    {
      icon: '🧠',
      title: 'Neurotechnology Concepts',
      desc: 'Sharing my learnings on BCI, neural signals, and the wild world of brain-computer interfaces.',
    },
  ];

  return (
    <section id="tutorials" className="tutorials-section">
      <div className="section-wrap">
        <h2 className="section-title">Tutorials & <span>Teaching</span> 🎓</h2>
        <p className="section-subtitle">sharing knowledge is my favorite thing 💝</p>

        <div className="tutorials-grid reveal">
          {cards.map(c => (
            <div className="tutorial-card" key={c.title}>
              <span className="tutorial-icon">{c.icon}</span>
              <h3>{c.title}</h3>
              <p>{c.desc}</p>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: 48 }} className="reveal">
          <p style={{ color: 'var(--soft)', fontWeight: 700, marginBottom: 18, fontSize: '1rem' }}>
            Watch my tutorials on YouTube! 🎬
          </p>
          <a
            className="yt-link"
            href="https://www.youtube.com/@from.haneul"
            target="_blank"
            rel="noopener noreferrer"
            onClick={playPop}
          >
            ▶️ Visit my YouTube channel
          </a>
        </div>
      </div>
    </section>
  );
}

// ─── Contact Section ─────────────────────────────────────────────────
function Contact({ showToast }) {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sending, setSending] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    playPop();
    setSending(true);
    // Mailto fallback — opens email client
    const subject = encodeURIComponent(`Hi Devi! Message from ${form.name}`);
    const body = encodeURIComponent(`Hi Devi!\n\nFrom: ${form.name}\nEmail: ${form.email}\n\n${form.message}`);
    window.open(`mailto:devuz19693@gmail.com?subject=${subject}&body=${body}`, '_blank');
    setTimeout(() => {
      setSending(false);
      setForm({ name: '', email: '', message: '' });
      showToast('💌 Message sent! Talk soon~');
    }, 800);
  };

  return (
    <section id="contact" className="contact-section">
      <div className="section-wrap">
        <h2 className="section-title">Get In <span>Touch</span> 💌</h2>
        <p className="section-subtitle">i'd love to hear from you! let's connect 🌸</p>

        <div className="contact-wrap">
          <div className="contact-form-card reveal">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Your name ✨</label>
                <input
                  type="text"
                  name="name"
                  placeholder="What should I call you?"
                  value={form.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Your email 📧</label>
                <input
                  type="email"
                  name="email"
                  placeholder="your@email.com"
                  value={form.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Your message 💬</label>
                <textarea
                  name="message"
                  placeholder="Tell me something fun! Or let's collaborate? 🚀"
                  value={form.message}
                  onChange={handleChange}
                  required
                />
              </div>
              <button className="btn-primary" type="submit" style={{ width: '100%' }}>
                {sending ? '✨ Opening mail...' : '💌 Send Message'}
              </button>
            </form>
          </div>

          <p style={{ textAlign: 'center', color: 'var(--soft)', fontWeight: 700, marginTop: 44, marginBottom: 8, fontSize: '1rem' }}>
            let's connect on socials too! 🫶
          </p>

          <div className="connect-links reveal">
            <a
              className="connect-link"
              href="https://www.linkedin.com/in/devichandrans/"
              target="_blank"
              rel="noopener noreferrer"
              onClick={playPop}
            >
              <span className="cl-icon">💼</span>
              LinkedIn
            </a>
            <a
              className="connect-link"
              href="https://www.youtube.com/@from.haneul"
              target="_blank"
              rel="noopener noreferrer"
              onClick={playPop}
            >
              <span className="cl-icon">▶️</span>
              YouTube
            </a>
            <a
              className="connect-link"
              href="mailto:devuz19693@gmail.com"
              onClick={playPop}
            >
              <span className="cl-icon">📧</span>
              Email
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Toast Notification ──────────────────────────────────────────────
function Toast({ message, onClose }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3500);
    return () => clearTimeout(t);
  }, [onClose]);

  return <div className="toast">🌸 {message}</div>;
}

// ─── Main App ────────────────────────────────────────────────────────
export default function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg) => setToast(msg), []);

  const scrollTo = useCallback((id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  // Intersection observer for active nav + reveal animations
  useEffect(() => {
    const sections = document.querySelectorAll('section[id]');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(e => {
          if (e.isIntersecting && e.intersectionRatio > 0.3) {
            setActiveSection(e.target.id);
          }
        });
      },
      { threshold: 0.3 }
    );
    sections.forEach(s => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  // Reveal on scroll
  useEffect(() => {
    const reveals = document.querySelectorAll('.reveal');
    const revealObserver = new IntersectionObserver(
      (entries) => entries.forEach(e => {
        if (e.isIntersecting) e.target.classList.add('visible');
      }),
      { threshold: 0.1 }
    );
    reveals.forEach(r => revealObserver.observe(r));
    return () => revealObserver.disconnect();
  }, []);

  // Global click sparkles
  useEffect(() => {
    const handleClick = (e) => {
      if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
        createSparkle(e.clientX, e.clientY);
      }
    };
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  return (
    <>
      <Cursor />
      <BubblesBg />
      <Navbar active={activeSection} scrollTo={scrollTo} />
      <main>
        <Hero scrollTo={scrollTo} />
        <About />
        <Projects />
        <Tutorials />
        <Contact showToast={showToast} />
      </main>
      <footer>
        <p>made with 💖 by <span>Devi Chandran</span> · built with React · deployed on Vercel</p>
        <p style={{ marginTop: 6 }}>🧠 neurotechnology is the future and i'm here for it ✨</p>
      </footer>
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
    </>
  );
}
